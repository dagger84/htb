
Myanmartorrents.com is part of RedMyanmar Group (RM Group). This site is dedicated for Myanmar Torrents. You will be able to download music, movies, music videos, pictures, and other stuff that are related to Myanmar.
<br><br>
RM Group was established in 2003 with RedMyanmar.Net Web Portal. We had 8000+ forum posts and 1200+ members back in 2004 - 2005. Unfortunately, due to reasons which cannot be revealed, RedMyanmar.NET has been shut down. However, we are trying to rebuild RM.net and hope to bring the site up in the near future. Besides RedMyanmar.NET, we also have GoldeGeeks.Com, PoemsCorner.Com, and MyanmarTorrents.Com websites. RM Group would like to thank everyone who helped us start the RM Group.
<br><br>
Myanmar Torrents Team:
<br><br>
Thet Swe Htun - Myanmar<br>
Teza - U.S.<br>
Thet Twe Aung - Singapore<br>
Sai Lone - U.S.<br>
