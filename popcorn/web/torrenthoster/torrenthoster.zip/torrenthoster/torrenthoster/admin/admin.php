<? echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"; ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<title>Admin Home</title>

</head>

<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red">
<p>&nbsp;</p>
<table align="left" border="0" cellpadding="0" cellspacing="0" width="600" height="100%">

<tr>
<td colspan="6">
<img src="images/files management.gif" border="0">
</td>
</tr>

    <tr>
        <td width="50" height="20">
            <a href="../index.php?mode=directory"><img src="images/browse.jpg" width="38" border="0"></a>
        </td>
        <td width="50" height="20">
            <a href="./index.php?mode=listtorrents"><img src="images/list torrents.jpg" width="64" border="0"></a>
        </td>
        <td width="50" height="20">
            <a href="./index.php?mode=dead"><img src="images/dead torrents.jpg" width="74"  border="0"></a>
        </td>
        <td width="50" height="20">
				    <a href="./index.php?mode=list_cat"><img src="images/list categories.jpg" width="76"  border="0"></a>
</td>
	        <td width="50" height="20">
				<a href="./index.php?mode=add_cat"><img src="images/add categories.jpg" width="73"  border="0"></a>
			        </td>
			<td width="50" height="20">
			    <a href="./index.php?mode=add_subcat"><img src="images/add subcategories.jpg" width="90"  border="0"></a>
		</td>

    </tr>

    <tr>


    </tr>

<tr height="30">
</tr>

<tr>
<td colspan="6">
<img src="images/users management.gif" border="0">
</td>
</tr>


    <tr>

        <td width="50" height="30">
            <a href="./index.php?mode=users"><img src="images/users.jpg" width="38" border="0"></a>
        </td>
        <td width="50" height="30">
           <a href="./index.php?mode=ban"><img src="images/ban users.jpg" width="52"  border="0"></a>
        </td>
        <td width="50" height="30">
		  <a href="./index.php?mode=comments"><img src="images/comments.jpg" width="56"  border="0"></a>
        </td>
        <td width="50" height="30">
		  <a href="./index.php?mode=hack"><img src="images/hack.jpg" width="47"  border="0"></a>
        </td>

    </tr>

    <tr height="30">
	</tr>

	<tr>
	<td colspan="6">
	<img src="images/news management.gif" border="0">
	</td>
</tr>

    <tr>
        <td width="50" height="30">
				 <a href="./index.php?mode=insert_news"><img src="images/add news.jpg" width="53" border="0"></a>
				</td>
		<td width="50" height="30">
				 <a href="./index.php?mode=news"><img src="images/edit news.jpg" width="52" border="0"></a>
        </td>



    </tr>
    <tr height="50">

	    </tr>
	    <tr>
	        <td width="50" height="40" colspan="6">
	            <a href="../logout.php"><img src="images/logout.png" width="64" height="70" border="0"></a>
	        </td>

    </tr>
</table>
</body>

</html>
