<a href="<?=CFG->wwwroot?>/users/index.php?mode=changepassword">Change password</>
